// Netlify Function — وسيط سناب شات
// يحل مشكلة CORS نهائياً بدون أي سيرفر خارجي

exports.handler = async function(event) {
  const headers = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization,Content-Type,X-Snap-Path,X-Snap-Method',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const token   = event.headers['authorization'] || '';
    const path    = event.headers['x-snap-path']   || 'me';
    const method  = event.headers['x-snap-method'] || event.httpMethod || 'GET';
    const snapURL = `https://adsapi.snapchat.com/v1/${path}`;

    const options = {
      method,
      headers: {
        'Authorization': token,
        'Content-Type':  'application/json'
      }
    };

    if (method !== 'GET' && event.body) {
      options.body = event.body;
    }

    const res  = await fetch(snapURL, options);
    const text = await res.text();

    return {
      statusCode: res.status,
      headers,
      body: text
    };

  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'proxy_error', message: err.message })
    };
  }
};
