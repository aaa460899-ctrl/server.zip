// ═══════════════════════════════════════════════
//  سناب إعلان — سيرفر OAuth كامل
//  ارفعه على Railway وضع المتغيرات الأربعة فقط
// ═══════════════════════════════════════════════
const https = require('https');
const http  = require('http');
const url   = require('url');

const PORT    = process.env.PORT             || 3000;
const CID     = process.env.SNAP_CLIENT_ID   || '';
const CSECRET = process.env.SNAP_CLIENT_SECRET || '';
const REDIR   = process.env.REDIRECT_URI     || '';
const FRONT   = process.env.FRONTEND_URL     || '';

// طلب HTTPS مساعد
function call(opts, body) {
  return new Promise((ok, fail) => {
    const r = https.request(opts, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { ok({ s: res.statusCode, b: JSON.parse(d) }); }
        catch { ok({ s: res.statusCode, b: d }); }
      });
    });
    r.on('error', fail);
    if (body) r.write(body);
    r.end();
  });
}

const CORS = {
  'Access-Control-Allow-Origin' : '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization,Content-Type',
  'Content-Type': 'application/json'
};

http.createServer(async (req, res) => {
  Object.entries(CORS).forEach(([k,v]) => res.setHeader(k,v));
  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

  const { pathname, query } = url.parse(req.url, true);

  // ─── /auth ── يحوّل المستخدم لصفحة سناب ───
  if (pathname === '/auth') {
    if (!CID) {
      res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
      res.end(`<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8">
        <style>body{font-family:Cairo,sans-serif;background:#0d0d1a;color:#f0f0ff;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
        .box{background:#1e1e3a;border:1px solid rgba(255,252,0,.2);border-radius:16px;padding:40px;text-align:center;max-width:400px}
        h2{color:#FFFC00;margin-bottom:16px}p{color:#7070a0;line-height:1.6;font-size:14px}
        code{background:rgba(255,255,255,.08);padding:4px 8px;border-radius:6px;font-size:12px;display:block;margin:8px 0;word-break:break-all}</style>
        </head><body><div class="box">
        <h2>⚙️ يحتاج إعداد</h2>
        <p>أضف هذه المتغيرات في Railway:</p>
        <code>SNAP_CLIENT_ID</code><code>SNAP_CLIENT_SECRET</code>
        <code>REDIRECT_URI = https://YOUR-SERVER.railway.app/callback</code>
        <code>FRONTEND_URL = رابط موقعك على Netlify</code>
        </div></body></html>`);
      return;
    }
    const authUrl =
      'https://accounts.snapchat.com/login/oauth2/authorize'
      + '?client_id='    + CID
      + '&redirect_uri=' + encodeURIComponent(REDIR)
      + '&response_type=code'
      + '&scope=snapchat-marketing-api';
    res.writeHead(302, { Location: authUrl });
    res.end();
    return;
  }

  // ─── /callback ── سناب ترجع هنا بعد الموافقة ───
  if (pathname === '/callback') {
    const { code, error } = query;
    if (error || !code) {
      res.writeHead(302, { Location: FRONT + '?snap_error=' + (error||'cancelled') });
      res.end(); return;
    }
    try {
      // 1. استبدل code بـ access_token
      const body = new URLSearchParams({
        client_id: CID, client_secret: CSECRET,
        redirect_uri: REDIR, grant_type: 'authorization_code', code
      }).toString();

      const tr = await call({
        hostname: 'accounts.snapchat.com',
        path: '/login/oauth2/access_token',
        method: 'POST',
        headers: { 'Content-Type':'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(body) }
      }, body);

      const token = tr.b.access_token;
      if (!token) throw new Error('no_token');

      // 2. جلب معرّف الحساب تلقائياً
      let accountId = '', accountName = 'حساب الإعلانات', email = '';
      try {
        const me = await call({ hostname:'adsapi.snapchat.com', path:'/v1/me', method:'GET', headers:{'Authorization':'Bearer '+token} });
        email = me.b?.me?.email || '';
        const orgId = me.b?.me?.organization_id;
        if (orgId) {
          const ac = await call({ hostname:'adsapi.snapchat.com', path:'/v1/organizations/'+orgId+'/adaccounts', method:'GET', headers:{'Authorization':'Bearer '+token} });
          const first = (ac.b?.adaccounts||[])[0];
          if (first) { accountId = first.adaccount.id; accountName = first.adaccount.name || accountName; }
        }
      } catch {}

      // 3. أعد للفرونت مع البيانات
      const redirect = FRONT
        + '?snap_token='   + encodeURIComponent(token)
        + '&snap_account=' + encodeURIComponent(accountId)
        + '&snap_name='    + encodeURIComponent(accountName)
        + '&snap_email='   + encodeURIComponent(email);
      res.writeHead(302, { Location: redirect });
      res.end();
    } catch(e) {
      res.writeHead(302, { Location: FRONT + '?snap_error=token_failed' });
      res.end();
    }
    return;
  }

  // ─── /api/* ── وسيط لـ Snap API (يحل CORS) ───
  if (pathname.startsWith('/api/')) {
    const snapPath = pathname.slice(5);
    const token = (req.headers['authorization']||'').replace('Bearer ','');
    if (!token) { res.writeHead(401); res.end(JSON.stringify({error:'no_token'})); return; }
    let body = '';
    req.on('data', c => body += c);
    req.on('end', async () => {
      try {
        const r = await call({
          hostname: 'adsapi.snapchat.com',
          path: '/v1/'+snapPath,
          method: req.method,
          headers: { 'Authorization':'Bearer '+token, 'Content-Type':'application/json' }
        }, body||undefined);
        res.writeHead(r.s); res.end(JSON.stringify(r.b));
      } catch { res.writeHead(500); res.end(JSON.stringify({error:'proxy_error'})); }
    });
    return;
  }

  // ─── /health ── فحص السيرفر ───
  if (pathname === '/health') {
    res.writeHead(200);
    res.end(JSON.stringify({
      ok: true,
      ready: !!(CID && CSECRET && REDIR && FRONT),
      missing: [!CID&&'SNAP_CLIENT_ID',!CSECRET&&'SNAP_CLIENT_SECRET',!REDIR&&'REDIRECT_URI',!FRONT&&'FRONTEND_URL'].filter(Boolean)
    }));
    return;
  }

  res.writeHead(404); res.end('not found');
}).listen(PORT, () => console.log('✅ Snap Server on port ' + PORT));
